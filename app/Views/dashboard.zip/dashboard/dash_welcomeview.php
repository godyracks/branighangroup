<?= $this->extend('layouts/dash_base') ?> 
<?= $this->section('dash_content') ?>

<div class="welcome-message">
        <h1>Welcome to the Branighan Group Dashboard</h1>
        <p>Manage your properties, designs, and blog with ease.</p>
    </div>

<?= $this->endSection() ?>